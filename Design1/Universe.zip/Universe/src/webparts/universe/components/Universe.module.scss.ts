/* tslint:disable */
require("./Universe.module.css");
const styles = {
  universe: 'universe_eb531033',
  container: 'container_eb531033',
  row: 'row_eb531033',
  column: 'column_eb531033',
  'ms-Grid': 'ms-Grid_eb531033',
  title: 'title_eb531033',
  subTitle: 'subTitle_eb531033',
  description: 'description_eb531033',
  button: 'button_eb531033',
  label: 'label_eb531033'
};

export default styles;
/* tslint:enable */