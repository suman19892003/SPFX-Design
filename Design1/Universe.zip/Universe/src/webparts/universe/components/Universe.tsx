import * as React from 'react';
import styles from './Universe.module.scss';
import { IUniverseProps } from './IUniverseProps';
import { escape } from '@microsoft/sp-lodash-subset';
import './styles/Navbar.css';
import $ from "jquery"
import "./styles/style.css"
const icici: any = require('./images/icici.jpg')
const searchIcon: any = require('./images/search24px.svg')
const notifications: any = require('./images/notificationsnone24px.svg')
 const account: any = require('./images/accountcircle24px.svg')
const iView: any = require('./images/iview.svg')
const travelClaims: any = require('./images/travelclaims.svg')
 const eForms: any = require('./images/eforms.svg')
const ecircular: any = require('./images/ecirculars.svg')
 const add: any = require('./images/add.svg')
const moreLinks: any = require('./images/morelinks.svg')
const iconAnnouncement: any = require('./images/iconannouncement.png')
const iconApproval: any = require('./images/iconapproval.svg')
 const iconDocument: any = require('./images/icondocument.svg')
 const iconDocuments: any = require('./images/icondocuments.png')
const iconShare: any = require('./images/iconshare.png')
const Path_5597: any = require('./images/Path5597.svg')
const Group8579: any = require('./images/Group8579.svg')
const Group9: any = require('./images/MaskGroup9.png')
const nounForm1236251: any = require('./images/nounforms1236251.svg')
const downloadingIcon: any = require('./images/downloadicon.jpg')
 const nounProducts1375585: any = require('./images/nounproducts1375585.svg')
const Group8432: any = require('./images/Group8432.svg')
const Group8598: any = require('./images/Group8598.svg')
const nounTickets1532094: any = require('./images/nountickets1532094.svg')
const birthday: any = require('./images/birthday1.jpg')
 const nounConfetti1395941: any = require('./images/nounConfetti1395941.svg')

export default class Universe extends React.Component<IUniverseProps, {}> {
  componentDidMount() {
    $(function () {
      $("li").click(function () {
        $("li").removeClass("active");
        $(this).addClass("active"); 
      });
    });
  }
  public render(): React.ReactElement<IUniverseProps> {
    return (
  
      <div className={styles.universe}> 
        {/* <!-- Header --> */}
          <div className="header">    
            <div className="row">
              <div className="col-lg-3 col-md-12 col-sm-12 col-xs-12 " >
                <img className="image" src={icici}></img>
              </div>
              <div className=" col-lg-6 col-md-12 col-sm-12 col-xs-12 searchCriteria">
                 <img src={searchIcon}></img>
                <input className="form-control search-box" type="text" placeholder="What are you looking for? " aria-label="Search" />
                 </div>

              <div className="col-lg-2 col-md-12 col-sm-12 col-xs-12 dateTime ">
                <span >Mon 28 Jun</span><br />
                <span>2:30pm</span>
              </div>
              <div className="col-lg-1 col-md-12 col-sm-12 col-xs-12 notification-icons">
                <img className="notify" src={notifications} ></img>     
               <span className="notificationIcon"></span>
                <img className="account" src={account} ></img>
              </div>
            </div>
          </div>

        {/* <!-- Navbar --> */}
       
          <nav className="navbar navbar-expand-lg navbar-light  nav">
            <a className="navbar-brand" href="#"></a>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse " id="navbarSupportedContent">
              <ul className="navbar-nav mr-auto">
                <li className="nav-item active ">
                  <a className=" items " href="#">Home</a>
                </li>
                <li className="nav-item dropdown ">
                  <a className=" items dropdown-toggle " href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    All Products
                  </a>
                  <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a className="sub-item items " href="#">Option 1</a>
                    <a className="sub-item items " href="#">Option 2</a>
                    <a className="sub-item items" href="#">Option 3</a>
                  </div>
                </li>
                <li className="nav-item dropdown ">
                  <a className="  dropdown-toggle items " href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Business Groups
                  </a>
                  <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a className="sub-item items" href="#">Option 1</a>
                    <a className="sub-item items " href="#">Option 2</a>
                    <a className="sub-item items" href="#">Option 3</a>
                  </div>
                </li>
                <li className="nav-item dropdown ">
                  <a className="  dropdown-toggle items " href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    My Docs
                  </a>
                  <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a className="sub-item items" href="#">Option 1</a>
                    <a className="sub-item items" href="#">Option 2</a>
                    <a className="sub-item items" href="#">Option 3</a>
                  </div>
                </li>
                <li className="nav-item dropdown ">
                  <a className="  dropdown-toggle items" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Know Your Bank
                  </a>
                  <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a className="sub-item items" href="#">Option 1</a>
                    <a className="sub-item items" href="#">Option 2</a>
                    <a className="sub-item items" href="#">Option 3</a>
                  </div>
                </li>
                <li className="nav-item dropdown ">
                  <a className=" dropdown-toggle items" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    HRMS
                  </a>
                  <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a className="sub-item items " href="#">Option 1</a>
                    <a className="sub-item items " href="#">Option 2</a>
                    <a className="sub-item items" href="#">Option 3</a>
                  </div>
                </li>
                <li className="nav-item active ">
                  <a className=" items" href="#">Blogs</a>
                </li>
              </ul>
            </div>
          </nav>

          <div className="container mt-5 text-left">
        <div className="row">
          <div className="col-md-8 col-sm-12 p-md-0">
            <div className="cards-section d-sm-flex justify-content-around">
              <div className="card">
                <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                  <img src={iView} alt="iview" />
                  <p className="font-weight-bold">iView</p>
                </div>
              </div>
              <div className="card">
                <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                  <img src={travelClaims}  alt="iview" />
                  <p className="font-weight-bold">Travel Claims</p>
                </div>
              </div>
              <div className="card">
                <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                  <img src={eForms}  alt="iview" />
                  <p className="font-weight-bold">E-Forms</p>
                </div>
              </div>
              <div className="card">
                <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                  <img src={ecircular} alt="iview" />
                  <p className="font-weight-bold">E-Circulars</p>
                </div>
              </div>
              <div className="card">
                <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                  <img src={add} alt="iview" />
                  <p className="font-weight-bold">Add</p>
                </div>
              </div>
              <div className="card">
                <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                  <img src={add}alt="iview" />
                  <p className="font-weight-bold">Add</p>
                </div>
              </div>
              <div className="card">
                <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                  <img src={moreLinks} alt="iview" />
                  <p className="font-weight-bold">More Links</p>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-4 col-sm-12">
            <div className="survey-section position-relative text-white rounded">
              <p className="mb-2">Last reminder to complete ICICI Bank<br /> Universe user experience survey</p>
              <button type="button" className="btn btn-success">Complete now</button>
              <img src={iconAnnouncement} className="right-section position-absolute" alt="share" />
            </div>
          </div>

          
          <div className="col-md-6 col-sm-12 mt-4 p-md-0">
            <div id="slider" className="carousel slide" data-ride="carousel">
              <ol className="carousel-indicators">
                <li data-target="#slider" data-slide-to="0" className="active"></li>
                <li data-target="#slider" data-slide-to="1"></li>
                <li data-target="#slider" data-slide-to="2"></li>
              </ol>
              <div className="carousel-inner">
                <div className="carousel-item active">
                  <div className="carousel-caption d-block text-left">
                      <h6>Town Hall Announcements</h6>
                      <h1>ICICI Bank and PhonePe Partner to issue FASTag</h1>
                      <h5>PhonePe users would now get a fully digitised experience; wouldn't have to visit physical stores, toll locations to buy a FASTag</h5>
                      <button type="button" className="btn px-4 text-white mt-3">Know more</button>
                    </div>
                </div>
                <div className="carousel-item">
                  <div className="carousel-caption d-block text-left">
                      <h6>Town Hall Announcements 2</h6>
                      <h1>ICICI Bank Example 2 to issue FASTag 2</h1>
                      <h5>PhonePe users would now get a fully digitised experience; wouldn't have to visit physical stores, toll locations to buy a FASTag 2</h5>
                      <button type="button" className="btn px-4 text-white mt-3">Know more</button>
                    </div>
                </div>
                <div className="carousel-item">
                  <div className="carousel-caption d-block text-left">
                      <h6>Town Hall Announcements 3</h6>
                      <h1>ICICI Bank Example 3 to issue FASTag 3</h1>
                      <h5>PhonePe users would now get a fully digitised experience; wouldn't have to visit physical stores, toll locations to buy a FASTag 3</h5>
                      <button type="button" className="btn px-4 text-white mt-3">Know more</button>
                    </div>
                </div>
              </div>
              <img src={iconAnnouncement} className="right-section position-absolute" alt="share" />
            </div>
          </div>

          <div className="col-md-3 col-sm-12 mt-4 pr-md-0">
            <div className="card rounded p-3 my-approvals fix-height">
              <div className="title mb-2 d-flex align-items-center">
                <div className="d-flex rounded-circle circle-bg mr-2 justify-content-center align-items-center">
                  <img src={iconApproval} alt="approval" />
                </div>
                <h6 className="mb-1 font-weight-bold">My Approvals (28)</h6>
              </div>
              <div className="d-flex justify-content-between approval-section py-2">
                <div className="d-flex flex-column">
                  <div className="d-flex">
                    <p className="font-weight-bold">HRMS</p>
                  </div>
                  <p>
                    Leave Request
                  </p>
                </div>
                <div className="d-flex align-items-center">
                  <div className="text-left">
                    <h2>2</h2>
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-between approval-section py-2">
                <div className="d-flex flex-column">
                  <div className="d-flex">
                    <p className="font-weight-bold">iExpense</p>
                  </div>
                  <p>
                    Process
                  </p>
                </div>
                <div className="d-flex align-items-center">
                  <div className="text-left">
                    <h2>4</h2>
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-between approval-section py-2">
                <div className="d-flex flex-column">
                  <div className="d-flex">
                  <p className="font-weight-bold">iExpense</p>
                  </div>
                  <p>
                    Process
                  </p>
                </div>
                <div className="d-flex align-items-center">
                  <div className="text-left">
                    <h2>1</h2>
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-between approval-section py-2">
                <div className="d-flex flex-column">
                  <div className="d-flex">
                    <p className="font-weight-bold">Whizible Initiative</p>
                  </div>
                  <p>
                    Pending
                  </p>
                </div>
                <div className="d-flex align-items-center">
                  <div className="text-left">
                    <h2>11</h2>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <a href="#">View all</a>
              </div>
            </div>
          </div>

          <div className="col-sm-3 mt-4">
            <div className="card rounded p-3 my-documents fix-height">
              <div className="title mb-2 d-flex align-items-center">
                <div className="d-flex rounded-circle circle-bg mr-2 justify-content-center align-items-center">
                  <img src={iconDocument}alt="approval" />
                </div>
                <h6 className="mb-1 font-weight-bold">My Documents (8)</h6>
              </div>
              <div className="d-flex justify-content-start documents-section py-2">
                <div className="d-flex rect-bg mr-2 justify-content-center align-items-center">
                  <img src={iconDocuments} alt="approval" />
                </div>
                <div className="d-flex flex-column">
                  <div className="d-flex">
                    <p className="document-title">Cheque collection policy</p>
                  </div>
                  <div className="small document-status">
                    Last opened 3hr ago
                  </div>
                </div>
                <div className="d-flex align-items-center ml-auto">
                  <img src={iconShare} alt="share" />
                </div>
              </div>
              <div className="d-flex justify-content-start documents-section py-2">
                <div className="d-flex rect-bg mr-2 justify-content-center align-items-center">
                  <img src={iconDocuments} alt="approval" />
                </div>
                <div className="d-flex flex-column">
                  <div className="d-flex">
                    <p className="document-title">List of outsourced vendors terminated by the Bank</p>
                  </div>
                  <div className="small document-status">
                    Last opened 5hr ago
                  </div>
                </div> 
                <div className="d-flex align-items-center ml-auto">
                  <img src={iconShare} alt="share" />
                </div>
              </div>
              <div className="d-flex justify-content-start documents-section py-2">
                <div className="d-flex rect-bg mr-2 justify-content-center align-items-center">
                  <img src={iconDocument} alt="approval" />
                </div>
                <div className="d-flex flex-column">
                  <div className="d-flex">
                    <p className="document-title">Servicing you Safely</p>
                  </div>
                  <div className="small document-status">
                    Last opened 5hr ago
                  </div>
                </div>
                <div className="d-flex align-items-center ml-auto">
                  <img src={iconShare} alt="share" />
                </div>
              </div>
              <div className="d-flex justify-content-start documents-section py-2">
                <div className="d-flex rect-bg mr-2 justify-content-center align-items-center">
                  <img src={iconShare} alt="approval" />
                </div>
                <div className="d-flex flex-column">
                  <div className="d-flex">
                    <p className="document-title">Business Continuity Management</p>
                  </div> 
                  <div className="small document-status">
                    Last opened 1day ago
                  </div>
                </div>
                <div className="d-flex align-items-center ml-auto">
                  <img src={iconShare} alt="share" />
                </div>
              </div>
              <div className="text-right">
                <a href="#">View all</a>
              </div>
            </div>
          </div>

        </div>
      </div>

       
        {/* social-media cards is started */}
        <div className="container">
          <div className="row">
            <div className=".col-xl-3 col-lg-3 col-md-6 col-sm-12 co-xs-12 p-md-0">
              <div className="card team-chart  mt-2">
                <div className="header-section mb-3">
                  <img src={Path_5597} />
                  <span className="header-title">Team Chart</span>
                  <img className=" float-right" src={Group8579} />
                </div>
                  <div className="sub-head">
                  <div className="sub-head-nav">
                    <ul> 
                      <li><a href="#">Team Chat<span className="badge notification1">20</span></a></li>
                      <li><a href="#">Knowledge Bites<span className="badge notification2">10</span></a></li>
                    </ul>
                  </div>
                </div>
                <div className="scroll-custom card-data">
                  <div className="card-body teams-chart-body mb-2" style={{ padding: "0px" }}>
                    <div className="heading-section mb-2">
                      <div className="profile-photo">
                        <img src={Group9} />
                        <span className="dot aciveStatus"></span>
                      </div>
                      <div className="profile-details">
                        <span className="profileName">Amrish Jain</span><br />
                        <span className="profileDate">jan 12, 01:29 pm</span>
                      </div>
                      <br />
                    </div>
                    <div className="content-text">
                      <p className="card-text-para">
                        <span >Jeetesh </span>The policy for fund transfer online to overseas has been updated. Here’s the latest
                        document
                      </p>
                    </div>
                    <div className="footer-card">
                      <img className="file-uploading" src={nounForm1236251} />
                      <span>funds transfer overseas.pdf</span>
                      <img className="file-downolading" src={downloadingIcon} />
                    </div>
                    <br />
                  </div>
                  <div className="card-body teams-chart-body mb-2" style={{ padding: "0px" }}>
                    <div className="heading-section mb-2">
                      <div className="profile-photo">
                        <img src={Group9} />
                        <span className="dot aciveStatus"></span>
                      </div>
                      <div className="profile-details">
                        <span>Amrish Jain</span>
                        <span>jan 12, 01:29 pm</span>
                      </div>
                      <br />
                    </div>
                    <div className="content-text">
                      <p className="card-text-para">
                        <span>Jeetesh </span>Jeetesh iTrack product team meeting to discuss new changes tomorrow 10am.
                      </p>
                    </div>
                    <div className="footer-card">
                      <img className="file-uploading" src={nounForm1236251} />
                      <span>funds transfer overseas.pdf</span>
                      <img className="file-downolading" src={downloadingIcon} />
                    </div>
                    <br />
                  </div>
                </div>
                <div className="new-msg">
                  <div className="card-header">
                    <input type="text" placeholder="Type a new massage. Use @ to mention" />
                  </div>
                </div>
              </div>
            </div>

            <div className=".col-xl-3 col-lg-3 col-md-6 col-sm-12 co-xs-12 pr-md-0">
              <div className="card product-card mb-2 mt-2">
                <div className="header-section mb-3">
                  <img src={nounProducts1375585} />
                  <span className="header-title">My Products(2)</span>
                </div>
                <div className="product-inside-card">
                  <div className="card-body" >
                    <div className="row">
                      <div className="col-lg-2 col-md-2 col-sm-2 col-2 " style={{ padding: "0px" }} >
                        <img src={Group8432} />
                      </div>
                      <div className="col-lg-10 col-md-10 col-sm-10 col-10 ">
                        <h6 className="card-title-heading">Credit Cards</h6>
                        <p className="card-text-para">Credit Cards offer a host of benefits and offers to cater to your needs.</p>
                        <a href="#" className="card-link">Know More</a>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="product-inside-card">
                  <div className="card-body" >
                    <div className="row">
                      <div className="col-lg-2 col-md-2  col-sm-2 col-2 product-inside-card-img" style={{ padding: "0px" }}>
                        <img src={Group8598} />
                      </div>
                      <div className="col-lg-10 col-md-10 col-sm-10 col-10">
                        <h6 className="card-title-heading">Forex Prepaid Cards</h6>
                        <p className="card-text-para">Browse through our range of Forex Prepaid Cards You can also avoid the
                          effects of
                          currency</p>
                        <a href="#" className="card-link">Know More</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className=".col-xl-3 col-lg-3 col-md-6 col-sm-12 co-xs-12 pr-md-0">
              <div className="card product-card mb-2 mt-2">
                <div className="header-section mb-3">
                  <img src={nounTickets1532094} />
                  <span className="header-title">My Tickets (7)</span>
                </div>
                <div className="sub-head">
                  <div className="sub-head-nav">
                    <ul>
                      <li><a href="#">Pending<span className="badge notification2">20</span></a></li>
                      <li><a href="#">Resolved<span className="badge notification1">10</span></a></li>
                    </ul>
                  </div>
                </div>

                <div className="sub-head"> 
                  <div className="ticket-blog">
                    <p className="ticket-slab">Printer is not connecting to laptop</p>
                    <span className="ticket-slab-id">INC00122084</span>
                    <span className="ticket-slab-days">1d ago</span>
                  </div>
                </div>

                <div className="sub-head">
                  <div className="ticket-blog">
                    <p className="ticket-slab">Laptop is heating up frequently</p>
                    <span className="ticket-slab-id">INC00322488</span>
                    <span className="ticket-slab-days">2d ago</span>
                  </div>
                </div>

                <div className="sub-head">
                  <div className="ticket-blog">
                    <p className="ticket-slab">New business cards</p>
                    <span className="ticket-slab-id">INC00322488</span>
                    <span className="ticket-slab-days">2d ago</span>
                  </div>
                </div>
                <div className="view-history">
                  <a href="#">View all</a>
                </div>

              </div>
            </div>

            <div className=".col-xl-3 col-lg-3 col-md-6 col-sm-12 co-xs-12">
              <div className="card team-chart mb-2 mt-2">
                <div className="header-section mb-3">
                  <img src={nounConfetti1395941} />
                  <span className="header-title">Celebrations</span>
                  <img className=" float-right" src={Group8579} />
                </div>
                <div className="sub-head">
                  <div className="sub-head-nav">
                    <ul>
                      <li><a href="#">Birthday<span className="badge  notification2">20</span></a></li>
                      <li><a href="#">Aniversary<span className="badge  notification1">10</span></a></li>
                      <li><a href="#">Recogtion<span className="badge notification1">10</span></a></li>
                    </ul>
                  </div>
                </div>
                <div className="date-card mt-2">
                  <span>july 2021</span>
                </div>
                <div className="scroll-custom card-data">
                  <div className=" cel-chart-body mb-2" >
                    <div className="heading-section mb-2">
                      <div className="profile-photo1">
                        <img src={Group9} />
                        <span className="dot aciveStatus"></span>
                      </div>
                      <div className="e-cards-title">
                        <p>Anoop Soni</p>
                        <span><img src={birthday} /> Today</span>
                      </div>
                      <div className="e-card-btn">
                        <button type="button" className="btn btn-outline-primary">Send E-card</button>
                      </div>
                    </div>
                  </div>

                  <div className=" cel-chart-body mb-2" >
                    <div className="heading-section mb-2">
                      <div className="profile-photo1">
                        <img src={Group9} />
                        <span className="dot aciveStatus"></span>
                      </div>
                      <div className="e-cards-title">
                        <p>Anoop Soni</p>
                        <span><img src={birthday} />Today</span>
                      </div>
                      <div className="e-card-btn">
                        <button type="button" className="btn btn-outline-primary">Send E-card</button>
                      </div>
                    </div>
                  </div>

                  <div className=" cel-chart-body mb-2" >
                    <div className="heading-section mb-2">
                      <div className="profile-photo1">
                        <img src={Group9} />
                        <span className="dot aciveStatus"></span>
                      </div>
                      <div className="e-cards-title">
                        <p>Anoop Soni</p>
                        <span><img src={birthday}/>Today</span>
                      </div>
                      <div className="e-card-btn">
                        <button type="button" className="btn btn-outline-primary">Send E-card</button>
                      </div>
                    </div>

                   </div>
                </div>

              </div>
            </div>
 
          </div>
        </div>

        {/* social-media cards is started */}

      </div>

    );
  }
}




