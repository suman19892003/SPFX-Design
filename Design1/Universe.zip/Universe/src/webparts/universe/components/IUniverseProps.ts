export interface IUniverseProps {
  description: string;
}
