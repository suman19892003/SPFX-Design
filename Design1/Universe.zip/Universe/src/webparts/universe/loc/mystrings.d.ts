declare interface IUniverseWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'UniverseWebPartStrings' {
  const strings: IUniverseWebPartStrings;
  export = strings;
}
