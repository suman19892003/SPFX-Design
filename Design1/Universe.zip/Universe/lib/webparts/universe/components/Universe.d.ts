import * as React from 'react';
import { IUniverseProps } from './IUniverseProps';
import './styles/Navbar.css';
import "./styles/style.css";
export default class Universe extends React.Component<IUniverseProps, {}> {
    componentDidMount(): void;
    render(): React.ReactElement<IUniverseProps>;
}
//# sourceMappingURL=Universe.d.ts.map