export interface IUniverseProps {
    description: string;
}
//# sourceMappingURL=IUniverseProps.d.ts.map