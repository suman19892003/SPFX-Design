import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import "../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import '../../../node_modules/popper.js/dist/popper.min.js';
import '../../../node_modules/bootstrap/dist/js/bootstrap.min.js';
export interface IUniverseWebPartProps {
    description: string;
}
export default class UniverseWebPart extends BaseClientSideWebPart<IUniverseWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=UniverseWebPart.d.ts.map